import { FormControlBase } from './formcontrol-base';

export class TextAreaControl extends FormControlBase<string> {

  constructor(parms: {} = {}) {
    super(parms);
  }
}
export class RequestedForm {

    public idRequested: string = "0"
    public status: string = "waiting"
    public formDefinition: any = {}

    constructor(parms: {} = {}) {
    }


}
import { NgModule } from '@angular/core';
// import { FooterComponent } from './footer/footer';
//import { DynamicFormControlComponent } from './dynamic-form-control/dynamic-form-control';
//import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';

@NgModule({
	declarations: 
	[ 
	],
	imports: [],
	exports: [
	]
})
export class ComponentsModule { }

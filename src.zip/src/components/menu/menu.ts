import { ActionSheetController } from 'ionic-angular'
import { Component } from '@angular/core';

@Component({
  selector: 'menu',
  templateUrl: 'menu.html'
})
export class MenuComponent {

  public appPages = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'List',
      url: '/list',
      icon: 'list'
    }
  ];

  constructor(public actionSheetCtrl: ActionSheetController) {
    console.log('Hello MenuComponent Component');
  }
} // class



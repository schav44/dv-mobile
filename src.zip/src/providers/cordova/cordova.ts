import { Injectable } from '@angular/core';
import { Device } from '@ionic-native/device';
//

/*
  Wrapper to provide Cordova functions or to return approriate
  responses where cordova is not used.
*/

@Injectable()
export class CordovaProvider {

  constructor(public device: Device )
  {
    console.log("CordovaProvider constructor()")
  }

  getDeviceInfo(): string {
    let msg = "<br/>Running in Browser mode..."
    if (this.isCordova()) {
      msg = + "<br/>Manufacturer:  " + this.device.manufacturer
        + "<br/>Model:  " + this.device.model
        + "<br/>Device uuid:  " + this.device.uuid
        + "<br/>Serial:  " + this.device.serial
        + "<br/>Cordova:  " + this.device.cordova
        + "<br/>Platform:  " + this.device.platform
        + "<br/>Version:  " + this.device.version
        + "<br/>Is Virtual:  " + this.device.isVirtual

    }
    return msg

  }

  isCordova(): boolean {
    let rc: boolean = false
    try {
      if (this.device.cordova != null) {
        rc = true
      }
    }
    catch (ex) {

    }
    return rc
  }


}


import { Injectable } from '@angular/core';
import { File } from '@ionic-native/file';
//
import { Defines } from '../../common/defines'

@Injectable()
export class CfgProvider {

  // Default device configuration parameters
  // the device configuration parms sent from the server can override these
  deviceParms: any =
    {
      deviceType: "PC",
      pollInterval: 1 * 60 * 1000,       // send polls this often
      pollDiffTime: 30 * 1000,          // don't poll if the last poll was this close
      screenX: 300,                  // screen dims in pixels
      screenY: 400,
      panelTextRows: 9,
      panelTextCols: 18
    }

    defFullListboxWidth: number = 290
    defFullListboxHeight: number = 300

    // The following is calculated from the platform at app component costruction time:
    platformHeight: number = 480
    platformWidth: number = 320

    def: Defines = new Defines()

    labMode: number = 0

  constructor( private file: File) {
    console.log("CfgProvider constructor()")
    // Check to see if we are running the browser in lab mode
    let urlStr = window.location.href
    // console.log('CfgProvider Provider href: '+ urlStr );
    let url = new URL(urlStr);
    let searchParams = new URLSearchParams(url.search);
    let labModeStr = searchParams.get(this.def.DEF_KEY_LABMODE)

    this.showDirectoryPathNames()
    
    if (labModeStr) {
      if (labModeStr == "1" || labModeStr == "true") {
        this.labMode = 1
        console.log ("Running in LAB MODE lab=1 specified")
      }
    }
    else {
      // no lab mode specified
    }

    console.log('CfgProvider LAB MODE: ' + this.labMode + " (0=not in lab mode, 1=in lab mode)");

  }

  setDeviceType(type: string) {
    this.deviceParms[this.def.DEF_KEY_DEVICETYPE] = type
  }
  
  getDeviceType(): string {
    return this.deviceParms[this.def.DEF_KEY_DEVICETYPE]
  }

  updateDeviceCfg(obj: any) {
    // for each key in the passed object update the the value of the local attribute
    for (let key in obj) {
      this.deviceParms[key] = obj[key]
      // console.log("CfgProvider: updateDeviceCfg() key/value:" + key + " / " + obj[key])
    }
  }

  /**
   * Returns the device type when running in browser mode only.
   * In browser mode, a window.location (url) string wil exist which has a query parm named 'device='
   * specifying the device type.
   * When running in Android mode, the device type comes from a configuration file stored on the device.
   */
  getDeviceTypeFromURL(): string {
    let url: string = window.location.toString()
    let devicetype: string = this.def.DEF_KEY_DEFAULTDEVICETYPE  // defasult
    if (url) {
      // locate the ?device= substring in the url
      let n = this.def.DEF_KEY_DEVICELOCATOR.length
      let i = url.lastIndexOf(this.def.DEF_KEY_DEVICELOCATOR)
      if (i > -1) {
        devicetype = url.substring(i) // get everything including the delimeter
        let i2 = devicetype.indexOf("&")
        if (i2 > -1) {
          devicetype = devicetype.substring(n, i2)
        }
        else {
          devicetype = devicetype.substring(n)
        }
      }
      if (devicetype.length < 1) devicetype = this.def.DEF_KEY_DEFAULTDEVICETYPE
    }
    // console.log("HomePage: getDeviceTypeFromURL(): devicetype=" + devicetype)
    return devicetype
  }


  /**
   * Save some parms from the style class definition.
   * These are: fulllistbox width, height
   * 
   * @param classes 
   */
  saveCssParms(classes: string) {
    if (!classes) return
    
    let tmps: string = ""
    let arr : string[] = []
    arr = this.getClassSectionFromStyleSheet( ".form_ctl_fulllistbox", classes)
    tmps = this.getCssStyleValueFromClass( "width", arr)
    tmps = tmps.replace(/px/g, "").trim()
    let w : number = Number(tmps)
    tmps = this.getCssStyleValueFromClass( "height", arr)
    tmps = tmps.replace(/px/g, "").trim()
    let h : number = Number(tmps)
    
    if (w > -1 && h > -1)
    {
      this.defFullListboxWidth = w
      this.defFullListboxHeight = h
    }

  }

  /**
   * Return the value of a specified style in the array of style definitions.
   * Example: return 200px for the style width from [ "width: 200px", "height: 300px"]
   * @param name 
   * @param stylesArr 
   */
  getCssStyleValueFromClass( name: string, stylesArr: string []) : string
  {
    let val: string = ""
    let tmparr: string [] = []
    for ( let i=0; i < stylesArr.length; i++)
    {
      tmparr = stylesArr[i].split(":")
      if ( tmparr[0].trim() == name )
      {
        val = tmparr[1]
        break
      }
    }
    return val
  }

  /**
   * Return the section for the specified class name from the full style sheet
   * The class style definitions are returned as an array of strings of "style : value"
   * @param name 
   */
  getClassSectionFromStyleSheet( name: string, classes: string): string []
  {
    if (!classes) return
    let tmps: string = ""
    let arr : string[] = []

    // find the ".form_ctl_fulllistbox" and extract style
    let i = classes.indexOf( name, 0)
    if ( i > -1)
    {
      // get the portion between { }
      let b1 = classes.indexOf("{", i)
      if ( b1 > -1)
      {
        let b2 = classes.indexOf("}", b1)
        if ( b2> -1)
        {
          tmps = classes.substring(b1 + 1, b2)
          arr = tmps.split( ";")
        }
      }
      
    }
    return arr
  }

  addMiscParmsToFormDefinition( formDef: {} ): {}
  {
    // let obj : {} = {}
    let ret : {} = null

    if (formDef)
    {
      let obj = {
        "classWidth" : this.defFullListboxWidth,
        "classHeight" : this.defFullListboxHeight
      }
      formDef["miscParms"] = obj
      ret = formDef
    }
    return ret
  }

  showDirectoryPathNames() 
  {
    console.log ( "DynamicFormPage: folder names:")

    console.log ( "CfgProvider: applicationDirectory: RO:" + this.file.applicationDirectory)
    console.log ( "CfgProvider: applicationStorageDirectory: RO:" + this.file.applicationStorageDirectory)
    console.log ( "CfgProvider: dataDirectory: **: "+ this.file.dataDirectory)
    console.log ( "CfgProvider: cacheDirectory:  : "+ this.file.cacheDirectory)
    console.log ( "CfgProvider: externalDataDirectory:  : "+ this.file.externalDataDirectory)

  }

  //---  LOCAL SORAGE CLASSES ---

  // localStorage_clear()
  // {
  //   window.localStorage.clear()
  // }

  // localeStorage_dump() {
  //   console.log(" >>> LOCAL STORAGE (HomePage): ")
  //   console.log(" >>> requestedForm: " + window.localStorage.getItem("requestedForm"))
  //   console.log(" >>> userid: " + window.localStorage.getItem("userid"))
  //   console.log(" >>> token: " + window.localStorage.getItem("token"))
  //   console.log(" >>> newToken: " + window.localStorage.getItem("newToken"))
  //   console.log(" >>> confirmToken: " + window.localStorage.getItem("confirmToken"))

  // }



} // class


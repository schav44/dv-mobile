
import { Injectable } from '@angular/core';
import { Events } from 'ionic-angular';
import { Platform } from 'ionic-angular';
import { Device } from '@ionic-native/device';
import { AlertController } from 'ionic-angular';
//
import { CordovaProvider } from '../../providers/cordova/cordova'

@Injectable()
export class BarcodeProvider {

  private lastScanTime: string = ""
  private requestResultCodes = "false";

  // TC8000 DATAWEDGE BARCODE RELATED:
  private dataWedgeVersion = "Pre 6.3. Please create & configure profile manually.  See the ReadMe for more details.";
  private availableScannersText = "Requires Datawedge 6.3+"
  private activeProfileText = "Requires Datawedge 6.3+";
  private commandResultText = "Messages from DataWedge will go here";
  private scanners = [{ "SCANNER_NAME": "Please Wait...", "SCANNER_INDEX": 0, "SCANNER_CONNECTION_STATE": true }];

  constructor(public events: Events, private platform: Platform, cordova: CordovaProvider,
    private device: Device, private alertCtrl: AlertController) {

    console.log("BarcodeProvider constructor()")
    this.events.unsubscribe( "datawedge:scan")

    this.platform.ready().then((readySource) => {

      if (!cordova.isCordova()) return
      let constructorInstance = this
      this.datawedgeConstructor();

      //  The Datawedge service will respond via implicit broadcasts intents.  
      //  Responses may be the result of calling the Datawedge API or may be because a barcode was scanned
      //  Set up a broadcast receiver to listen for incoming scans
      (<any>window).plugins.intentShim.registerBroadcastReceiver({
        filterActions: [
          'com.ibm.dview.mobile.ACTION',           //  Response from scan (needs to match value in output plugin)
          'com.symbol.datawedge.api.RESULT_ACTION'//  Response from DataWedge service (as defined by API)
        ],
        filterCategories: [
          'android.intent.category.DEFAULT'
        ]
      },
        function (intent) {
          //  Broadcast received
          // console.log('Received Intent: ' + JSON.stringify(intent.extras));

          //  Emit a separate event for the result associated with this scan.  This will only be present in response to
          //  API calls which included a SEND_RESULT extra
          if (intent.extras.hasOwnProperty('RESULT_INFO')) {
            let commandResult = intent.extras.RESULT + " (" +
              intent.extras.COMMAND.substring(intent.extras.COMMAND.lastIndexOf('.') + 1, intent.extras.COMMAND.length) + ")";  // + JSON.stringify(intent.extras.RESULT_INFO);
            constructorInstance.events.publish('data:commandResult', commandResult.toLowerCase());
          }

          if (intent.extras.hasOwnProperty('com.symbol.datawedge.api.RESULT_GET_VERSION_INFO')) {
            //  The version has been returned (DW 6.3 or higher).  Includes the DW version along with other subsystem versions e.g MX  
            var versionInfo = intent.extras['com.symbol.datawedge.api.RESULT_GET_VERSION_INFO'];
            // console.log('Version Info: ' + JSON.stringify(versionInfo));
            let datawedgeVersion = versionInfo['DATAWEDGE'];
            // console.log("Datawedge version: " + datawedgeVersion);

            //  Fire events sequentially so the application can gracefully degrade the functionality available on earlier DW versions
            if (datawedgeVersion >= "6.3")
              constructorInstance.events.publish('status:dw63ApisAvailable', true);
            if (datawedgeVersion >= "6.4")
              constructorInstance.events.publish('status:dw64ApisAvailable', true);
            if (datawedgeVersion >= "6.5")
              constructorInstance.events.publish('status:dw65ApisAvailable', true);
          }
          else if (intent.extras.hasOwnProperty('com.symbol.datawedge.api.RESULT_ENUMERATE_SCANNERS')) {
            //  Return from our request to enumerate the available scanners
            let enumeratedScanners = intent.extras['com.symbol.datawedge.api.RESULT_ENUMERATE_SCANNERS'];
            constructorInstance.events.publish('data:enumeratedScanners', enumeratedScanners);
          }
          else if (intent.extras.hasOwnProperty('com.symbol.datawedge.api.RESULT_GET_ACTIVE_PROFILE')) {
            //  Return from our request to obtain the active profile
            let activeProfile = intent.extras['com.symbol.datawedge.api.RESULT_GET_ACTIVE_PROFILE'];
            constructorInstance.events.publish('data:activeProfile', activeProfile);
          }
          else if (!intent.extras.hasOwnProperty('RESULT_INFO')) {
            //  A barcode has been scanned

            // console.log("BarcodeProvider RECEIVED INTENT: " + JSON.stringify(intent) + "   !!!!!!!!!!!")

            constructorInstance.events.publish('data:scan', intent, new Date().toLocaleTimeString());

          }
        }
      );




    });  // this.platform.ready().then

  }  // constructor

  //  Control whether or not to include the SEND_RESULT extra in our commands to request DW send the
  //  result back to us.  Only available in DW6.5+
  requestResult(requestCodes: boolean) {
    this.requestResultCodes = "" + requestCodes;
  }

  //  Send a broadcast intent to the DW service which is present on all Zebra devcies.
  //  This functionality requires DW6.3+ as that is the version where the com.symbol.datawedge.api.ACTION
  //  was introduced.
  //  extraValue may be a String or a Bundle
  sendCommand(extraName: string, extraValue) {
    // console.log("Sending Command: " + extraName + ", " + JSON.stringify(extraValue));
    (<any>window).plugins.intentShim.sendBroadcast({
      action: 'com.symbol.datawedge.api.ACTION',
      extras: {
        [extraName]: extraValue,
        "SEND_RESULT": this.requestResultCodes
      }
    },
      function () { },  //  Success in sending the intent, not success of DW to process the intent.
      function () { }   //  Failure in sending the intent, not failure of DW to process the intent.
    );
  }


  datawedgeConstructor() {
    console.log(" DynamicFormPage: datawedgeConstructor: ")

    this.platform.ready().then((readySource) => {

      //  Check manufacturer.  Exit if this app is not running on a Zebra device
      console.log("Device manufacturer is: " + this.device.manufacturer);
      if (!(this.device.manufacturer.toLowerCase().includes("zebra") || this.device.manufacturer.toLowerCase().includes("motorola solutions"))) {
        let alert = this.alertCtrl.create({
          title: 'Requires Zebra device',
          subTitle: 'This application requires a Zebra mobile device in order to run',
          cssClass: 'nonZebraAlert',
          buttons: [{
            text: 'Close app',
            handler: data => {
              console.log('Closing application since we are not running on a Zebra device');
              this.platform.exitApp();
            }
          }]
        });
        alert.present();
      }

      //  Determine the version.  We can add additional functionality if a more recent version of the DW API is present
      // this.barcodeProvider.sendCommand("com.symbol.datawedge.api.GET_VERSION_INFO", "");
      this.sendCommand("com.symbol.datawedge.api.GET_VERSION_INFO", "");

      ////////////////////////////
      //  EVENT HANDLING
      ////////////////////////////

      //  6.3 DataWedge APIs are available
      this.events.subscribe('status:dw63ApisAvailable', (isAvailable) => {
        // console.log("DataWedge 6.3 APIs are available");
        //  We are able to create the profile under 6.3.  If no further version events are received, notify the user
        //  they will need to create the profile manually
        this.sendCommand("com.symbol.datawedge.api.CREATE_PROFILE", "IBMDViewMobile");
        this.dataWedgeVersion = "6.3.  Please configure profile manually.  See the ReadMe for more details.";

        //  Although we created the profile we can only configure it with DW 6.4.
        this.sendCommand("com.symbol.datawedge.api.GET_ACTIVE_PROFILE", "");

        //  Enumerate the available scanners on the device
        this.sendCommand("com.symbol.datawedge.api.ENUMERATE_SCANNERS", "");

        //  Functionality of the FAB is available so display the button
      });

      //  6.4 Datawedge APIs are available
      this.events.subscribe('status:dw64ApisAvailable', (isAvailable) => {
        // console.log("DataWedge 6.4 APIs are available");

        //  Documentation states the ability to set a profile config is only available from DW 6.4.
        //  For our purposes, this includes setting the decoders and configuring the associated app / output params of the profile.
        this.dataWedgeVersion = "6.4";

        //  Configure the created profile (associated app and keyboard plugin)
        let profileConfig = {
          "PROFILE_NAME": "IBMDViewMobile",
          "PROFILE_ENABLED": "true",
          "CONFIG_MODE": "UPDATE",
          "PLUGIN_CONFIG": {
            "PLUGIN_NAME": "BARCODE",
            "RESET_CONFIG": "true",
            "PARAM_LIST": {}
          },
          "APP_LIST": [{
            "PACKAGE_NAME": "com.ibm.dview.mobile",
            "ACTIVITY_LIST": ["*"]
          }]
        };
        this.sendCommand("com.symbol.datawedge.api.SET_CONFIG", profileConfig);

        //  Configure the created profile (intent plugin)
        let profileConfig2 = {
          "PROFILE_NAME": "IBMDViewMobile",
          "PROFILE_ENABLED": "true",
          "CONFIG_MODE": "UPDATE",
          "PLUGIN_CONFIG": {
            "PLUGIN_NAME": "INTENT",
            "RESET_CONFIG": "true",
            "PARAM_LIST": {
              "intent_output_enabled": "true",
              "intent_action": "com.ibm.dview.mobile.ACTION",

              "intent_delivery": "2"
            }
          }
        };
        // this.barcodeProvider.sendCommand("com.symbol.datawedge.api.SET_CONFIG", profileConfig2);
        this.sendCommand("com.symbol.datawedge.api.SET_CONFIG", profileConfig2);

        //  Give some time for the profile to settle then query its value
        setTimeout(function () {
          this.sendCommand("com.symbol.datawedge.api.GET_ACTIVE_PROFILE", "");
        }, 1000);

      });

      //  6.5 Datawedge APIs are available
      this.events.subscribe('status:dw65ApisAvailable', (isAvailable) => {
        // console.log("DataWedge 6.5 APIs are available");

        //  The ability to switch to a new scanner is commandResultTextnly available from DW 6.5 onwards
        //  Reconfigure UI so the user can choose the commandResultTextesired scanner
        //  6.5 also introduced messages which are received from the API to indicate success / failure
        this.requestResult(true);
        this.dataWedgeVersion = "6.5 or higher";
      });

      //  Response to our request to find out the active DW profile
      this.events.subscribe('data:activeProfile', (activeProfile) => {

        //  Update the UI
        this.activeProfileText = activeProfile;
      });

      //  The result (success / failure) of our last API call along with additional information
      this.events.subscribe('data:commandResult', (commandResult) => {
        this.commandResultText = commandResult;
      });

      //  Response to our requet to enumerte the scanners
      this.events.subscribe('data:enumeratedScanners', (enumeratedScanners) => {
        //  Maintain two lists, the first for devices which support DW 6.5+ and shows a combo box to select
        //  the scanner to use.  The second will just display the available scanners in a list and be available
        //  for 6.4 and below
        this.scanners = enumeratedScanners;
        this.scanners.unshift({ "SCANNER_NAME": "Please Select...", "SCANNER_INDEX": -1, "SCANNER_CONNECTION_STATE": false });
        let humanReadableScannerList = "";
        enumeratedScanners.forEach((scanner, index) => {
          console.log("Scanner found: name= " + scanner.SCANNER_NAME + ", id=" + scanner.SCANNER_INDEX + ", connected=" + scanner.SCANNER_CONNECTION_STATE);
          humanReadableScannerList += scanner.SCANNER_NAME;
          if (index < enumeratedScanners.length - 1)
            humanReadableScannerList += ", ";
        });
        this.availableScannersText = humanReadableScannerList;
      });

      //  A scan has been received
      this.events.subscribe('data:scan', (scanData, time) => {
        // console.log("DynamicFormPage: !!!!!!!!!!!!!!!!!! scan received: " )
        let scanTimeMillis = new Date().getTime()
        this.processDataWedgeInput(scanData, time, scanTimeMillis)
      });

    });

  }

  processDataWedgeInput(scanData, time, scanTimeMillis) {
    let scannedData = scanData.extras["com.symbol.datawedge.data_string"]
    scannedData = "]"+ scannedData // ADD SCANNER PREFIX  ??????????????????????????????????????define in cfgProvider ????????
    let event : any = {
      scannedData: scannedData
      ,timer: scanTimeMillis
    }
    console.log("BarcodeProvider: Datawedge scan: data:" + event.scanned + " event.timer: " + event.timer )
    this.events.publish("datawedge:scan", event)
  }

} // class


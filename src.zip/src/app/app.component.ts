
import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
//
import { CfgProvider } from '../providers/cfg/cfg'
import { StartPage } from '../pages/start/start';
import { MenuComponent } from "../components/menu/menu";

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any = StartPage;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public cfg : CfgProvider) {

    platform.ready().then((readySource) => {
      statusBar.styleDefault();
      splashScreen.hide();
      this.cfg.platformWidth = platform.width()
      this.cfg.platformHeight = platform.height()
    });
  }

}


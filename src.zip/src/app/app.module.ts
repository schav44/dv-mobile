
import { ErrorHandler } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { File } from '@ionic-native/file';
import { Device } from '@ionic-native/device';
import { Keyboard } from '@ionic-native/keyboard';
//
import { MyApp } from './app.component';
import { StartPage } from '../pages/start/start';
import { DynamicFormPage } from '../pages/dynamic-form/dynamic-form';
import { FormProvider } from '../providers/dynamic-form/dynamic-form';
import { DynamicFormComponent } from '../components/dynamic-form/dynamic-form.component';
import { DynamicFormControlComponent } from '../components/dynamic-form-control/dynamic-form-control';
import { FooterComponent } from '../components/footer/footer';
import { DvrestProvider } from '../providers/dvrest/dvrest';
import { CfgProvider } from '../providers/cfg/cfg';
import { CordovaProvider } from '../providers/cordova/cordova';
import { BarcodeProvider } from '../providers/barcode/barcode';
import { VoiceProvider } from '../providers/voice/voice';

@NgModule({
  declarations: [
    MyApp
    , StartPage
    , DynamicFormPage
    , DynamicFormComponent
    , DynamicFormControlComponent
    , FooterComponent
  ],
  imports: [
    BrowserModule
    , HttpModule
    , IonicModule.forRoot(MyApp)
  ],

  bootstrap: [IonicApp],

  entryComponents: [
    MyApp
    , StartPage
    , DynamicFormPage
  ],

  providers: [
    StatusBar,
    SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    HttpModule,
    FormProvider,
    DvrestProvider,
    Device,
    CfgProvider,
    CordovaProvider,
    Keyboard,
    
    File,
    BarcodeProvider,
    VoiceProvider
  ]
})
export class AppModule {

  constructor() {
    console.log("AppModule constructor(): ")


  }

}

// Represents attributes structure for form controls (defined in form xml files)
export interface ControlAttributes {
    styleClass?: string
    cssStyle?: {}
    allowEmptyValue?: string
    respectCase?: string
    validation?: string
}

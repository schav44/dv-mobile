

/**
 * This class defines common keywords and parameters
 * Use this class for constant values
 */

export class Defines {

    DEF_KEY_CFG: string = "configuration"
    DEF_KEY_DEVIDECFG: string = "deviceCfg"
    DEF_KEY_DEVICELOCATOR: string = "device="
    DEF_KEY_DEVICETYPE: string = "deviceType"
    DEF_KEY_DEFAULTSTYLECLASSESS: string = "defaultStyleClasses"
    DEF_KEY_USERID: string = "userid"
    DEF_KEY_BODY: string = "_body"
    DEF_KEY_REQUESTEDFORM: string = "requestedForm"
    DEF_KEY_STYLECLASS: string = "styleClass"
    DEF_KEY_CSSSTYLE: string = "cssStyle"
    DEF_KEY_MAXLENGTH: string = "maxlength"
    DEF_KEY_ALIGNMENT: string = "alignment"
    DEF_KEY_PROTECTMODE: string = "protectMode"
    DEF_KEY_NEXT: string = "next"
    DEF_KEY_SUBMITTYPE: string = "submitType"
    DEF_KEY_OPERATION: string = "operation"
    DEF_KEY_OPERATION_CLEARED: string = "operation_cleared"
    DEF_KEY_VALIDATION: string = "validation"
    DEF_KEY_ALLOWEMPTYVALUE: string = "allowEmptyValue"
    DEF_KEY_RESPECTCASE: string = "respectCase"
    DEF_KEY_AUTOFOCUS: string = "autofocus"
    DEF_KEY_AUTOSELECT: string = "autoSelect"
    DEF_KEY_STATUSLINE: string = "statusLine"
    DEF_KEY_STATUSLINESTYLE: string = "statusLineStyle"
    DEF_KEY_STATUSLINECLASS: string = "statusLineClass"
    DEF_KEY_ENTER: string = "Enter"
    DEF_KEY_POLLINFO: string = "pollinfo"
    DEF_KEY_POLLINTERVAL = "pollInterval"
    DEF_KEY_POLLDIFFTIME = "pollDiffTime"
    DEF_KEY_SCREENX = 300
    DEF_KEY_SCREENY = 350
    DEF_KEY_URL_ROOT = "urlroot"
    DEF_KEY_LABMODE = "lab"
    DEF_KEY_FOOTERTITLE= 'footerTitle'
    DEF_KEY_CLASSWIDTH = 'classWidth'
    DEF_KEY_CLASSHEIGHT = 'classHeight'
    DEF_KEY_MISCPARMS = 'miscParms'
  
    // DEF_KEY_PASSWORD: string = "password"
    DEF_KEY_DEFAULTDEVICETYPE: string = "PC"
    DEF_KEY_ONSUBMITTEXT: string = "OnSubmitText"
  
    DEF_SUBMITTYPE_SUBMIT: string = "submit"
    DEF_SUBMITTYPE_LOGOUT: string = "logout"
    DEF_SUBMITTYPE_ACTIONSHEET: string = "actionListSubmit"
  
    DEF_STATUS_WAITING: string = "waiting"
    DEF_STATUS_COMPLETED: string = "completed"
    DEF_STATUS_ERROR: string = "error"
  
    /*
    title
    label_MOBILE
    ctl_ActionSheet
    ctl_json
   */

    DEF_CTL_LABEL: string = "label"
    DEF_CTL_PANELTEXT: string = "ctl_paneltext"
    DEF_CTL_INPUT: string = "ctl_input"
    DEF_CTL_LISTBOX: string = "ctl_listbox"
    DEF_CTL_FULLLISTBOX: string = "ctl_fulllistbox"
    DEF_CTL_HTMLLISTBOX: string = "ctl_htmllistbox"
    DEF_CTL_TEXTAREA: string = "ctl_textarea"
    DEF_CTL_EXCEPTION: string = "ctl_Exception"
    DEF_CTL_ONSUBMITTEXT: string = "ctl_OnSubmitText"
    DEF_CTL_BUTTON: string = "button"
    DEF_CTL_FOOTERTITLE: string = 'form_ctl_footer_title'
    DEF_CTL_GRID: string = 'ctl_grid'
  
    DEF_BUTTON_OK = "ok"
    DEF_BUTTON_CANCEL = "cancel"
    DEF_BUTTON_SUBMIT = "submit"
    DEF_BUTTON_YES = "yes"
    DEF_BUTTON_NO = "no"
    DEF_BUTTON_LOGOUT = "logout"
    DEF_BUTTON_BACK = "back"
    DEF_BUTTON_ACTIONSHEET = "action"
  
    DEF_CFGFILE = 'DVMobile.device.json'

    DEF_PARM_PANELTEXTROWS: number = 9
    DEF_PARM_PANELTEXTCOLS: number = 18
    DEF_PARM_DEFDEVICE: string = "TC8000"

    DEF_VAL_NUMERIC = '0'
    DEF_VAL_ALPHA = '1'
    DEF_VAL_ALPHANUMERIC = '2'
    DEF_VAL_TEMPLATE = '3'
    DEF_VAL_NUMERICKEYPADONLY = '4'
    DEF_VAL_ALPHANUMERICSCANPREFERRED = '5'
    DEF_VAL_ALPHANUMERICSCANREQUIRED = '6'

    DEF_FOOTCMD_HIDESUBMIT = "hide_submit"
    
} // class